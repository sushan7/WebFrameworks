from django.apps import AppConfig


class RestoConfig(AppConfig):
    name = 'resto'
